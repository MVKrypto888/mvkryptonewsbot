BOT_TOKEN = '7977915751:AAG6lvmMAMOEAJmZAz5yARBYBth86F4TlUY'
CHANNEL_ID = '@mavkrypto'

# Максимум новин на спокійний день
MAX_NEWS_PER_DAY = 6

# Ключові слова для фільтрації
KEYWORDS = [
    'bitcoin', 'btc', 'eth', 'ethereum', 'crypto', 'binance', 'long', 'short',
    'etf', 'fed', 'liquidation', 'market', 'trading', 'pump', 'dump',
    'wallet', 'exchange', 'future', 'spot', 'volume', 'rsi', 'macd'
]
